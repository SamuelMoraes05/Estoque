create database matheus;
use matheus;



create table tb_cadUsuario(
id_Usuario int unsigned not null primary key auto_increment,
nome_Usuario varchar(255),
dtNasc_Usuario varchar(15),
email_Usuario varchar(255)unique,
senha_Usuario varchar(80),
dataCad_Usuario TIMESTAMP DEFAULT(CURRENT_TIMESTAMP())
);

create table tb_produtos(
id_produto int unsigned not null primary key auto_increment,
nome_produto varchar(40),
desc_produto varchar(255),
cod_produto varchar(30) unique,
quant_produto varchar(10),
fileira_produto varchar(70),
setor_produto varchar(70),
uso_produto varchar(5),
unidade_produto varchar(20),
anotacao_produto varchar(255)
);


create table tb_chaves(
id_chave int unsigned not null auto_increment primary key,
sala_chave varchar(80),
solicitante_chave varchar(80),
emailSolicitante_chave varchar(155),
telefoneSolicitante_chave varchar(20),
dataEHoraRetirada_chave  varchar(80),
dataEHoraDevolucao_chave varchar(80)
);

insert into tb_chaves(sala_chave,solicitante_chave,emailSolicitante_chave,telefoneSolicitante_chave,dataEHoraRetirada_chave,dataEHoraDevolucao_chave)
 values('Info lab 2','Ramom','ramomsenai@senai.com','27 995999-9999','dia 25/03/2005 as 8:40','dia 25/03/2005 as 17:40');
 
 select*from tb_chaves;
drop table tb_chaves;
