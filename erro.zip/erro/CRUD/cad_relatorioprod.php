<?php 
    $nome_relatorioprod = $_POST['nome_relatorioprod'];
    $cod_relatorioprod = $_POST['cod_relatorioprod'];
    $quant_relatorioprod = $_POST['quant_relatorioprod'];



    $cad_relatorioProd = $pdo->prepare("INSERT INTO tb_relatorioProduto(nome_relatorioprod,cod_relatorioprod,quant_relatorioprod) 
    VALUES(:nome_prod,:cod_prod,:quant_prod)");
    $cad_relatorioProd->execute(array(
        ':nome_prod' => $nome_prod,
        ':cod_prod' => $cod_prod,
        ':quant_prod' => $quant_prod,   
    ));

    echo "<script>
    alert('Cadastrado com Sucesso!');
    </script>";
    
?>