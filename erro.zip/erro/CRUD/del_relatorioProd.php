<?php
    require('../conn.php');

   if( isset($_GET['id_relatorioprod'])){
        $id_relatorioprod = $_GET['id_relatorioprod'];
   }else{
   }

   $del_prod = $pdo->prepare('DELETE FROM tb_relatorioProduto WHERE id_relatorioprod=:id_relatorioprod');
   $del_prod->execute(array(':id_relatorioprod'=>$id_relatorioprod));
   echo "<script>
   alert('Produto Deletado!');
   window.location.href='../relatorioProd.php';
   </script>";  
?>
