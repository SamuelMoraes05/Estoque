<?php
    require('../conn.php');

   if( isset($_GET['id_emprestimo'])){
        $id_emprestimo = $_GET['id_emprestimo'];
   }else{
   }

   $del_prod = $pdo->prepare('DELETE FROM tb_emprestimos WHERE id_emprestimo=:id_emprestimo');
   $del_prod->execute(array(':id_emprestimo'=>$id_emprestimo));
   echo "<script>
   alert('Emprestimo Deletado!');
   window.location.href='../tabelarelatorio.php';
   </script>";  
?>
