<?php
    require('../conn.php');

    $id_chave = $_POST['id_chave'];
    $sala_chave = $_POST['sala_chave'];
    $solici_chave = $_POST['solici_chave'];
    $EmailSolici_chave = $_POST['EmailSolici_chave'];
    $telSolici_chave = $_POST['telSolici_chave'];
    $dtEHoraRetirada_chave = $_POST['dtEHoraRetirada_chave'];
    $dtEHoraDevolucao_chave = $_POST['dtEHoraDevolucao_chave'];

  
    $update_chave = $pdo->prepare("UPDATE tb_chaves set
    sala_chave = :sala_chave,
    solicitante_chave = :solici_chave,
    emailSolicitante_chave = :EmailSolici_chave,
    telefoneSolicitante_chave = :telSolici_chave,
    dataEHoraRetirada_chave = :dtEHoraRetirada_chave,
    dataEHoraDevolucao_chave = :dtEHoraDevolucao_chave
    WHERE
    id_chave = :id_chave;");
    $update_chave->execute(array(
    ':id_chave' => $id_chave,
    ':sala_chave'=> $sala_chave,
    ':solici_chave'=> $solici_chave,
    ':EmailSolici_chave'=> $EmailSolici_chave,
    ':telSolici_chave'=> $telSolici_chave,
    ':dtEHoraRetirada_chave'=> $dtEHoraRetirada_chave,
    ':dtEHoraDevolucao_chave'=> $dtEHoraDevolucao_chave
    ));
    echo "<script>
        alert('Alteração Realizada!');
        window.history.go(-2);
        </script>";
    
    
?>
