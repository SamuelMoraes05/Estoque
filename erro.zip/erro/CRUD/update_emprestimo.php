<?php
    require('../conn.php');

    $id_emprestimo = $_POST['id_emprestimo'];
    $dataEHoraDevolucao_emprestimo = $_POST['dataEHoraDevolucao_emprestimo'];
    $quantidade_adicionar = $_POST['quantidade_adicionar'];
    $name_prod = $_POST['name_prod'];

    $update_emprestimo = $pdo->prepare("UPDATE tb_emprestimos SET dataEHoraDevolucao_emprestimo = :dataEHoraDevolucao_emprestimo WHERE id_emprestimo = :id_emprestimo;");
    $update_emprestimo->execute(array(
        ':id_emprestimo' => $id_emprestimo,
        ':dataEHoraDevolucao_emprestimo'=> $dataEHoraDevolucao_emprestimo
    ));
    
    $tabela = $pdo->prepare("SELECT quant_produto, nome_produto FROM tb_produtos WHERE nome_produto = :name_prod;");
    $tabela->execute(array(':name_prod' => $name_prod));
    $rowTable = $tabela->fetch();
    
    $quant_produto_atual = $rowTable['quant_produto'];
    
    $quant_produto_novo = $quant_produto_atual + $quantidade_adicionar;

    $update_produtos = $pdo->prepare("UPDATE tb_produtos SET quant_produto = :quant_produto_novo WHERE nome_produto = :name_prod;");
    $update_produtos->execute(array(
        ':quant_produto_novo' => $quant_produto_novo,
        ':name_prod' => $name_prod
    ));

    ?>
