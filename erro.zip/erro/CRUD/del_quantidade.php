<?php
require('../conn.php');

$quantidade_remover = $_POST['quantidade_remover'];
$id_produto = $_POST['id_produto'];

$tabela = $pdo->prepare("SELECT quant_produto FROM tb_produtos WHERE id_produto = :id_produto;");
$tabela->execute(array(':id_produto' => $id_produto));
$rowTable = $tabela->fetch();

$quant_produto_atual = $rowTable['quant_produto'];

if ($quant_produto_atual >= $quantidade_remover) {
    $quant_produto_novo = $quant_produto_atual - $quantidade_remover;

    $update_prod = $pdo->prepare("UPDATE tb_produtos SET quant_produto = :quant_produto WHERE id_produto = :id_produto;");
    $update_prod->execute(array(
        ':quant_produto' => $quant_produto_novo,
        ':id_produto' => $id_produto
    ));

    echo "<script>
        alert('Emprestimo Concluido com Sucesso!');
        window.location.href='../tabela.php';
    </script>";

    $quantidade_remover = $_POST['quantidade_remover']; 
    $nome_emprestimo = $_POST['nome_emprestimo']; 
    $solicitante_emprestimo = $_POST['solicitante_emprestimo'];
    $emailSolicitante_emprestimo = $_POST['emailSolicitante_emprestimo'];
    $telefoneSolicitante_emprestimo = $_POST['telefoneSolicitante_emprestimo'];
    $dataEHoraRetirada_emprestimo = $_POST['dataEHoraRetirada_emprestimo'];

    if (empty($solicitante_emprestimo) || empty($nome_emprestimo)|| empty($quantidade_remover) || empty($emailSolicitante_emprestimo) || empty($telefoneSolicitante_emprestimo)|| empty($dataEHoraRetirada_emprestimo)) {
        echo "Os valores não podem ser vazios";
    } else {

        $cad_emprestimo = $pdo->prepare("INSERT INTO tb_emprestimos(nome_emprestimo,quantidade_emprestimo,solicitante_emprestimo,emailSolicitante_emprestimo,telefoneSolicitante_emprestimo,
        dataEHoraRetirada_emprestimo) 
        VALUES(:nome_emprestimo,:quantidade_remover,:solicitante_emprestimo, :emailSolicitante_emprestimo, :telefoneSolicitante_emprestimo,:dataEHoraRetirada_emprestimo)");
        $cad_emprestimo->execute(array(
            ':nome_emprestimo' => $nome_emprestimo,
            ':quantidade_remover' => $quantidade_remover,
            ':solicitante_emprestimo' => $solicitante_emprestimo,
            ':emailSolicitante_emprestimo' => $emailSolicitante_emprestimo,
            ':telefoneSolicitante_emprestimo' => $telefoneSolicitante_emprestimo,
            ':dataEHoraRetirada_emprestimo' => $dataEHoraRetirada_emprestimo
            
        ));

        echo "<script>
        alert('Cadastrado com Sucesso!');
        window.location.href='../paginaPrincipal.php';
        </script>";
    }
} else {
    echo "<script>
        alert('Quantidade a ser removida é maior do que a quantidade disponível!');
        window.location.href='../tabela.php';
    </script>";
}
?>
