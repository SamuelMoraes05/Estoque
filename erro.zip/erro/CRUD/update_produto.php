<?php
    require('../conn.php');

    $id_produto = $_POST['id_produto'];
    $nome_produto = $_POST['nome_produto'];
    $desc_produto = $_POST['desc_produto'];
    $quant_produto = $_POST['quant_produto'];
    $fileira_produto = $_POST['fileira_produto'];
    $setor_produto = $_POST['setor_produto'];
    $uso_produto = $_POST['uso_produto'];
    $unidade_produto = $_POST['unidade_produto'];
    $anotacao_produto = $_POST['anotacao_produto'];

    
    $update_prod = $pdo->prepare("UPDATE tb_produtos set
    nome_produto = :nome_produto,
    desc_produto = :desc_produto,
    quant_produto = :quant_produto,
    fileira_produto = :fileira_produto,
    setor_produto = :setor_produto,
    uso_produto = :uso_produto,
    unidade_produto = :unidade_produto,
    anotacao_produto = :anotacao_produto
    WHERE
    id_produto = :id_produto;");
    $update_prod->execute(array(
    ':id_produto' => $id_produto,
    ':nome_produto'=> $nome_produto,
    ':desc_produto'=> $desc_produto,
    ':quant_produto'=> $quant_produto,
    ':fileira_produto'=> $fileira_produto,
    ':setor_produto'=> $setor_produto,
    ':uso_produto'=> $uso_produto,
    ':unidade_produto'=> $unidade_produto,
    ':anotacao_produto'=> $anotacao_produto
    ));
    echo "<script>
        alert('Alteração Realizada!');
        window.location.href='../tabela.php';
    </script>";
    
    
?>
