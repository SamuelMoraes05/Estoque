<?php
    require('../conn.php');

   if( isset($_GET['id_produto'])){
        $id_produto = $_GET['id_produto'];
   }else{
   }

   $del_prod = $pdo->prepare('DELETE FROM tb_produtos WHERE id_produto=:id_produto');
   $del_prod->execute(array(':id_produto'=>$id_produto));
   echo "<script>
   alert('Produto Deletado!');
   window.location.href='../tabela.php';
   </script>";  
?>
