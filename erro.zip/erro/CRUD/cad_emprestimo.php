<?php
require('../conn.php');


$nome_emprestimo = $_POST['nome_prod'];
$solicitante_emprestimo = $_POST['solicitante_emprestimo'];
$emailSolicitante_emprestimo = $_POST['emailSolicitante_emprestimo'];
$telefoneSolicitante_emprestimo = $_POST['telefoneSolicitante_emprestimo'];
$dataEHoraRetirada_emprestimo = $_POST ['dataEHoraRetirada_emprestimo'];

if (empty($solicitante_emprestimo) || empty($nome_emprestimo) || empty($emailSolicitante_emprestimo) || empty($telefoneSolicitante_emprestimo)|| empty($dataEHoraRetirada_emprestimo)) {
    echo "Os valores não podem ser vazios";
} else {

        $cad_emprestimo = $pdo->prepare("INSERT INTO tb_emprestimos(nome_emprestimo,solicitante_emprestimo,emailSolicitante_emprestimo,telefoneSolicitante_emprestimo,
        dataEHoraRetirada_emprestimo) 
        VALUES(:nome_prod,:solicitante_emprestimo, :emailSolicitante_emprestimo, :telefoneSolicitante_emprestimo,:dataEHoraRetirada_emprestimo)");
        $cad_emprestimo->execute(array(
            ':nome_prod' => $nome_prod,
            ':solicitante_emprestimo' => $solicitante_emprestimo,
            ':emailSolicitante_emprestimo' => $emailSolicitante_emprestimo,
            ':telefoneSolicitante_emprestimo' => $telefoneSolicitante_emprestimo,
            ':dataEHoraRetirada_emprestimo' => $dataEHoraRetirada_emprestimo
            
        ));

        echo "<script>
        alert('Cadastrado com Sucesso!');
        window.location.href='../paginaPrincipal.php';
        </script>";
    }

?>
