<?php
require('../conn.php');

$nome_prod = $_POST['nome_prod'];
$desc_prod = $_POST['desc_prod'];
$cod_prod = $_POST['cod_prod'];
$quant_prod = $_POST['quant_prod'];
$fileira_prod = $_POST['fileira_prod'];
$setor_prod = $_POST['setor_prod'];
$uso_prod = $_POST['uso_prod'];
$uni_prod = $_POST['uni_prod'];
$nota_prod = $_POST['nota_prod'];

if (empty($nome_prod) || empty($cod_prod) || empty($quant_prod) || empty($fileira_prod) || empty($setor_prod) || empty($uso_prod) || empty($uni_prod)) {
    echo "Os valores não podem ser vazios";
} else {
    $check_prod = $pdo->prepare("SELECT * FROM tb_produtos WHERE cod_produto = :cod_prod");
    $check_prod->execute(array(':cod_prod' => $cod_prod));
    $existing_product = $check_prod->fetch();

    if ($existing_product) {
        echo "<script>
            alert('ID já cadastrado, por favor escolha outro ID!');
            window.history.back();
        </script>";
    } else {
        $cad_product = $pdo->prepare("INSERT INTO tb_produtos(nome_produto, desc_produto, cod_produto, quant_produto, fileira_produto, setor_produto, uso_produto, unidade_produto, anotacao_produto) 
        VALUES(:nome_prod, :desc_prod, :cod_prod, :quant_prod, :fileira_prod, :setor_prod, :uso_prod, :uni_prod, :nota_prod)");

        $cad_product->execute(array(
            ':nome_prod' => $nome_prod,
            ':desc_prod' => $desc_prod,
            ':cod_prod' => $cod_prod,
            ':quant_prod' => $quant_prod,
            ':fileira_prod' => $fileira_prod,
            ':setor_prod' => $setor_prod,
            ':uso_prod' => $uso_prod,
            ':uni_prod' => $uni_prod,
            ':nota_prod' => $nota_prod
        ));

        

        $cad_relatorioProd = $pdo->prepare("INSERT INTO tb_relatorioProduto(nome_relatorioprod, cod_relatorioprod, quant_relatorioprod) 
        VALUES(:nome_prod, :cod_prod, :quant_prod)");
        $cad_relatorioProd->execute(array(
            ':nome_prod' => $nome_prod,
            ':cod_prod' => $cod_prod,
            ':quant_prod' => $quant_prod   
        ));

       
    }
}
?>
