<?php
require("conn.php");
require("protected.php");

if (isset($_POST['pesquisar'])) {
    $nome = $_POST['nome_pesquisa'];
    $tabela = $pdo->prepare("SELECT id_relatorioprod,nome_relatorioprod,cod_relatorioprod,cadastrante_relatorioprod,quant_relatorioprod FROM tb_relatorioProduto WHERE nome_relatorioprod LIKE :nome");
    $tabela->bindValue(':nome', "%$nome%", PDO::PARAM_STR);
    $tabela->execute();
    $rowTabela = $tabela->fetchAll();
} else {
    $tabela = $pdo->prepare("SELECT id_relatorioprod,nome_relatorioprod,cod_relatorioprod,cadastrante_relatorioprod,quant_relatorioprod FROM tb_relatorioProduto;");
    $tabela->execute();
    $rowTabela = $tabela->fetchAll();
}


?>


<!DOCTYPE html>
<html lang="en">
<head>
	<title>Tabela</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
	<div class="container-login100" style="background-image: url('https://mapa-da-obra-producao.s3.amazonaws.com/wp-content/uploads/2022/09/iStock-1138429558-scaled.jpg');">
		<div class="">

            <table class="table table-striped">
			<form action="" method="POST">
                <div class="mb-3">
                  <label for="nome_pesquisa" class="form-label">Pesquisar por Nome do Produto</label>
                  <div class="input-group">
                    <input type="text" class="form-control" id="nome_pesquisa" name="nome_pesquisa" required>
                    <button class="btn btn-primary" type="submit" name="pesquisar">Pesquisar</button>
					<br><br>
					<a href="relatorioProd.php" class="btn btn-secondary">Limpar Pesquisas</a>
                  </div>
                </div>
              </form>
  <thead>
    <tr>
	  <th scope="col">Nome Produto</th>
      <th scope="col">Cadastrante</th>
      <th scope="col">Código </th>
      <th scope="col">Quantidade</th>
    </tr>
  </thead>
  <tbody>
    <?php
    foreach ($rowTabela as $linha) {
        echo "<tr>";
        echo "<td>".$linha['nome_relatorioprod']."</td>";
        echo "<td>".$linha['cadastrante_relatorioprod']."</td>";
        echo "<td>".$linha['cod_relatorioprod']."</td>";
        echo "<td>".$linha['quant_relatorioprod']."</td>";
		echo '<td><a href="CRUD\del_relatorioProd.php?id_relatorioprod='.$linha['id_relatorioprod'].'" class="btn btn-danger" onclick="return confirm(\'Tem certeza que deseja excluir este produto?\')">Excluir</a></td>';
        echo "</tr>";
    }
    if (count($rowTabela) === 0) {
        echo "<tr><td colspan='7'>Nenhum produto encontrado.</td></tr>";
    }
    ?>
  </tbody>
</table>		
<div class="container-login100-form-btn">
    <a href="paginaPrincipal.php" class="login100-form-btn">voltar</a>		
</div>
<br>
					
					
<div class="container-login100-form-btn">
    <a href="logout.php" class="btn btn-danger">Sair da Conta</a>		
</div>

</div>
</div>
</div>
</body>
</html>
