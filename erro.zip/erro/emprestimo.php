<?php
require("conn.php");
require("protected.php");

if (isset($_GET['id_produto'])) {
    $produto = $_GET['id_produto'];
} else {
    header("Location: tabela.php");
}

$tabela = $pdo->prepare("SELECT * FROM tb_produtos WHERE id_produto=:id_produto;");
$tabela->execute(array(':id_produto' => $produto));
$rowTable = $tabela->fetchAll();
?>

<!DOCTYPE HTML>
<html lang="pt-br">
<head>
    <style>
        body {
            background-color: #f1f1f1;
            font-family: Arial, sans-serif;
        }

        .container {
            background-color: #ffffff;
            padding: 20px;
            margin: 50px auto;
            width: 400px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            margin-top: 0;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 10px;
        }

        input[type="number"] {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
            border: none;
        }

        .btn {
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px;
            cursor: pointer;
            font-size: 16px;
        }

        .btn:hover {
            background-color: #3e8e41;
        }
        .input-wrapper {
        position: relative;
        }

        .input-wrapper input[readonly] {
            cursor: not-allowed;
        }

        .input-wrapper .lock-icon {
            position: absolute;
            top: 50%;
            right: 10px;
            transform: translateY(-50%);
            color: #aaa;
        }


        .float-end {
            float: right;
        }
    </style>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <title>Cadastro de Problemas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>
<body>
<div class="container">
    <h1 style="text-align:center;">Emprestimo</h1>
    <br>
    <form action="CRUD/del_quantidade.php" method="post">
        <div class="form-group">
            <label for="">Quantidade para emprestimo</label required>
            <input type="number" name="quantidade_remover" class="form-control">
        </div><br>
        <div class="form-group">
    <label for="">Nome</label>
    <div class="input-wrapper">
        <input type="text" name="nome_emprestimo" class="form-control" value="<?php echo $rowTable[0]['nome_produto'] ?>" readonly>
        <span class="lock-icon">&#128274;</span>
    </div>
</div>
<br>
        <div class="form-group">
            <label for="">Solicitante</label>
            <input type="text" name="solicitante_emprestimo" class="form-control">
        </div><br>
        <div class="form-group">
            <label for="">Email Solicitante</label>
            <input type="text" name="emailSolicitante_emprestimo" class="form-control">
        </div><br>
        <div class="form-group">
            <label for="">Telefone Solicitante</label>
            <input type="text" name="telefoneSolicitante_emprestimo" class="form-control">
        </div><br>
        <div class="form-group">
            <label for="">Data e Hora Retirada</label>
            <input type="date" name="dataEHoraRetirada_emprestimo" class="form-control" required>
        </div><br>
        
        <br>
        <div class="form-group">
            <input type="submit" class="btn btn-success" value="Solicitar Emprestimo">
            <a href="tabela.php" type="button" class="btn btn-primary float-end">Voltar</a>
        </div>
        <input type="hidden" name="id_produto" value="<?php echo $rowTable[0]['id_produto'] ?>">
    </form>
    <div id="resultado"></div>
</div>
<script src="https://code.jquery.com/jquery-3.6.4.js"
        integrity="sha256-a9jBBRygX1Bh5lt8GZjXDzyOB+bWve9EiO7tROUtj/E="
        crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN"
        crossorigin="anonymous"></script>
</body>
</html>
