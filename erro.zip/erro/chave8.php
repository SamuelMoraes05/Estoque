<?php 
require("conn.php");
require("protected.php");

$tabela = $pdo->prepare("SELECT id_chave,sala_chave, solicitante_chave, emailSolicitante_chave,telefoneSolicitante_chave,dataEHoraRetirada_chave,dataEHoraDevolucao_chave
FROM tb_chaves WHERE id_chave LIKE 8;");
$tabela->execute();
$rowTabela = $tabela->fetchAll();

?>
 
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Chaves</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
    <style>
	.quadrado {
		width: auto;
		height: auto;
		background-color: rgba(192, 192, 192, 0.5); /* Fundo transparente com cor #c0c0c0 */
		border: 1px solid #000000;
		margin: 20px auto;
		text-align: center;
		padding: 20px;
		font-size: 20px;
		color: #000000;
        
	}
    
</style>

</head>
<body>
<div class="limiter">
	<div class="container-login100" style="background-image: url('https://mapa-da-obra-producao.s3.amazonaws.com/wp-content/uploads/2022/09/iStock-1138429558-scaled.jpg');">
		<div class="">

            <table class="table table-striped">
			<form action="" method="POST">
                <h1>Chave 8</h1>
                <br>
              </form>
                <thead>
                    <tr>
                    <th scope="col">Sala da Chave</th>
                    <th scope="col">Solicitante</th>
                    <th scope="col">Email Solicitante</th>
                    <th scope="col">Telefone Solicitante</th>
                    <th scope="col">Data e Hora de Retirada</th>
                    <th scope="col">Data e Hora da Devolução</th>
                    </tr>
                </thead>
  <tbody>
    <?php
    foreach ($rowTabela as $linha) {
        echo "<tr>";
        echo "<td>".$linha['sala_chave']."</td>";
        echo "<td>".$linha['solicitante_chave']."</td>";
        echo "<td>".$linha['emailSolicitante_chave']."</td>";
        echo "<td>".$linha['telefoneSolicitante_chave']."</td>";
        echo "<td>".$linha['dataEHoraRetirada_chave']."</td>";
        echo "<td>".$linha['dataEHoraDevolucao_chave']."</td>";
        echo '<td><a href="editarchave.php?id_chave='.$linha['id_chave'].'" class="btn btn-warning">Editar</a></td>';
        echo "</tr>";
    }
    ?>
  </tbody>
</table>		
<div class="container-login100-form-btn">
    <a href="chaves.php" class="login100-form-btn">voltar</a>		
</div>
<br>
					

</div>
</div>
</div>
</body>
</html>
