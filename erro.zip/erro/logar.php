<?php

include( "conn.php");

$login = $_POST['user'];
$senha = $_POST['senha'];

$usuario = $pdo->prepare('SELECT * FROM tb_cadUsuario WHERE
    email_Usuario = :email_Usuario
    AND senha_Usuario = :senha_Usuario');
    
$usuario->execute(array(
    ':email_Usuario' => $login,
    ':senha_Usuario' => $senha
));

$rowTabela = $usuario->fetchAll();

if (empty($rowTabela)) {
    echo "<script>
        alert('Usuário e/ou senha inválidos!!!');
        window.history.back();
    </script>";
} else {
    $sessao = $rowTabela[0];

    if (!isset($_SESSION)) {
        session_start();
    }

    $_SESSION['id_Usuario'] = $sessao['id_Usuario'];
    $_SESSION['email_Usuario'] = $sessao['email_Usuario'];
    $_SESSION['nome_Usuario'] = $sessao['nome_Usuario']; // Adiciona o nome do usuário à sessão

    header("Location: paginaPrincipal.php");
}

?>
