<?php
require("conn.php");
session_start();

// Resto do seu código...


date_default_timezone_set('America/Sao_Paulo');

// Verifica se é a primeira entrada na sessão
if (!isset($_SESSION['first_entry'])) {
    // Define a primeira entrada como true
    $_SESSION['first_entry'] = true;
} else {
    // Já houve uma entrada anterior, não exibe a mensagem de boas-vindas
    $_SESSION['first_entry'] = false;
}

$tabela = $pdo->prepare("SELECT id_Usuario, nome_Usuario FROM tb_cadUsuario;");
$tabela->execute();
$usuarios = $tabela->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <title>Cadastro</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--===============================================================================================-->
    <link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="css/util.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!--===============================================================================================-->

    <style>
        /* Estilos CSS para o popup de boas-vindas */
        .popup {
            display: none;
            position: fixed;
            z-index: 9999;
            left: 50%;
            top: calc(50% - 150px);
            transform: translate(-50%, -50%);
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
            padding: 30px;
            text-align: center;
            max-width: 300px;
        }

        .popup-title {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 15px;
        }

        .popup-message {
            font-size: 18px;
            margin-bottom: 15px;
        }

        .popup-close {
            display: inline-block;
            background-color: #ccc;
            padding: 5px 10px;
            border-radius: 3px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="limiter">
        <div class="container-login100" style="background-image: url('https://mapa-da-obra-producao.s3.amazonaws.com/wp-content/uploads/2022/09/iStock-1138429558-scaled.jpg');">
            <div class="wrap-login100">
                <span class="login100-form-logo">
                    <i class="zmdi zmdi-dropbox"></i>
                </span>

                <span class="login100-form-title p-b-34 p-t-27">
                    Selecione a Opção Desejada
                </span>
                <br><br>

                <div class="container-login100-form-btn">
                    <a href="criarProduto.php" class="login100-form-btn">ㅤㅤㅤㅤㅤㅤCadastrar Produtoㅤㅤㅤㅤㅤㅤ</a>
                </div>
                <br>
                <div class="container-login100-form-btn">
                    <a href="tabela.php" class="login100-form-btn">ㅤㅤㅤㅤㅤㅤㅤㅤEstoqueㅤㅤㅤㅤㅤㅤㅤㅤ</a>       
                </div>
                <br>
                <div class="container-login100-form-btn">
                    <a href="criarFuncionario.php" class="login100-form-btn">ㅤㅤㅤㅤCadastrar Funcionarioㅤㅤㅤㅤ</a>      
                </div>
                <br>
                <div class="container-login100-form-btn">
                    <a href="chaves.php" class="login100-form-btn">ㅤㅤㅤㅤㅤㅤㅤㅤChavesㅤㅤㅤㅤㅤㅤㅤㅤ</a>       
                </div>
                <br>
                <div class="container-login100-form-btn">
                    <a href="tabelaRelatorio.php" class="login100-form-btn">ㅤㅤㅤㅤRelatório de Empréstimoㅤㅤㅤ</a>       
                </div>
                <br>
                <div class="container-login100-form-btn">
                    <a href="relatorioProd.php" class="login100-form-btn">ㅤㅤㅤㅤㅤRelatório de Produtosㅤㅤㅤㅤ</a>       
                </div>
                <br><br>

                <div class="container-login100-form-btn">
                    <a href="logout.php" class="btn btn-danger">Sair da Conta</a>       
                </div>

                <?php


                // Obtém a hora atual
                $hora_atual = date('H:i');

                // Define a saudação de acordo com o horário
                if ($hora_atual >= '00:00' && $hora_atual <= '11:59') {
                    $saudacao = 'Bom dia';
                } elseif ($hora_atual >= '12:00' && $hora_atual <= '18:00') {
                    $saudacao = 'Boa tarde';
                } else {
                    $saudacao = 'Boa noite';
                }

                
                $id=$_SESSION['id_Usuario'];
                // seleciona o nome
                $select = $pdo -> prepare('SELECT * FROM tb_cadUsuario WHERE id_Usuario = :id_Usuario');
                $select -> execute([':id_Usuario' => $id]);
                $result = $select -> fetch();

                $l=rowcount($result);

                // Verifica se é a primeira entrada na sessão
                // if ($_SESSION['first_entry']) {

                    if(1==1){
                    echo '<div id="welcome-message" class="popup">';
                    echo "<div class='popup-title'>" . $saudacao . "," .$l. ' '.$_SESSION['id_Usuario'].
                    "</div>";
                    echo '<div class="popup-message">Espero que seu dia esteja sendo incrível! Bom Trabalho! </div>';
                    echo '<span class="popup-close" onclick="closePopup()">Fechar</span>';
                    echo '</div>';
                    echo '<script>
                            function closePopup() {
                                var popup = document.getElementById("welcome-message");
                                popup.style.display = "none";
                            }
                            document.addEventListener("DOMContentLoaded", function() {
                                var popup = document.getElementById("welcome-message");
                                popup.style.display = "block";
                                setTimeout(closePopup, 10000);
                            });
                          </script>';
                }

                

                ?>
            </div>
        </div>
    </div>

    <div id="dropDownSelect1"></div>
    
    <!--===============================================================================================-->
    <script src="vendor/jquery/jquery-3.2.1.min.js"></script>
    <!--===============================================================================================-->
    <script src="vendor/animsition/js/animsition.min.js"></script>
    <!--===============================================================================================-->
    <script src="vendor/bootstrap/js/popper.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <!--===============================================================================================-->
    <script src="vendor/select2/select2.min.js"></script>
    <!--===============================================================================================-->
    <script src="vendor/daterangepicker/moment.min.js"></script>
    <script src="vendor/daterangepicker/daterangepicker.js"></script>
    <!--===============================================================================================-->
    <script src="vendor/countdowntime/countdowntime.js"></script>
    <!--===============================================================================================-->
    <script src="js/main.js"></script>

</body>
</html>
