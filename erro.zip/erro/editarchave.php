<?php
require("conn.php");
require("protected.php");

if (isset($_GET['id_chave'])){
    $chave = $_GET['id_chave'];
} else {
    header("Location: tabela.php");
}

$tabela = $pdo->prepare("SELECT * FROM tb_chaves WHERE id_chave=:id_chave;");
$tabela->execute(array(':id_chave' => $chave));
$rowTable = $tabela->fetchAll();
?>

<!DOCTYPE HTML>
<html lang="pt-br">
<head>
    <style>
        body {
            background-color: #f1f1f1;
            font-family: Arial, sans-serif;
        }

        .container {
            background-color: #ffffff;
            padding: 20px;
            margin: 50px auto;
            width: 400px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            margin-top: 0;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 10px;
        }

        input[type="text"],
        input[type="password"],
        input[type="email"] {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
            border: none;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px;
            cursor: pointer;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            background-color: #3e8e41;
        }
    </style>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <title>Cadastro de Problemas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>
<body>
<div class="container">
    <h1 style="text-align:center;">Edição de Produtos</h1>
    <br>
    <form action="CRUD/update_chave.php" method="post" id="formulario">
        <div class="form-group offset-md-3">
            <div class="col-md-6">
                <label for="">Sala da Chave:</label>
                <input type="text" name="sala_chave" id="" class="form-control" value="<?php echo $rowTable[0]['sala_chave']?>">
            </div>
            <div class="col-md-6">
                <label for="">Solicitante:</label>
                <input type="text" name="solici_chave" id="" class="form-control" value="<?php echo $rowTable[0]['solicitante_chave']?>">
            </div>
        </div>
        <div class="form-group offset-md-3">
            <div class="col-md-6">
                <label for="">Email Solicitante: </label>
                <input type="text" name="EmailSolici_chave" id="" class="form-control" value="<?php echo $rowTable[0]['emailSolicitante_chave']?>">
            </div>
            <div class="col-md-6">
                <label for="">Telefone Solicitante: </label>
                <input type="text" name="telSolici_chave" id="" class="form-control" value="<?php echo $rowTable[0]['telefoneSolicitante_chave']?>">
            </div>
            <div class="col-md-6">
                <label for="">Data e Hora de Retirada: </label>
                <input type="text" name="dtEHoraRetirada_chave" id="" class="form-control" value="<?php echo $rowTable[0]['dataEHoraRetirada_chave']?>">
            </div>
            <div class="col-md-6">
                <label for="">Data e Hora da Devolução: </label>
                <input type="text" name="dtEHoraDevolucao_chave" id="" class="form-control" value="<?php echo $rowTable[0]['dataEHoraDevolucao_chave']?>">
            </div>
        </div>
        <br>
        <div class="form-group offset-md-3">
            <div class="col-md-6">
                <input type="submit" class="btn btn-success" value="SALVAR ALTERAÇÕES">
                <a href="chave1.php" type="button" class="btn btn-primary float-end">Voltar</a>
            </div>
        </div>
        <input type="hidden" name="id_chave" value="<?php echo $rowTable[0]['id_chave']?>">
    </form>
    <div id="resultado"></div>
</div>
<script src="https://code.jquery.com/jquery-3.6.4.js"
        integrity="sha256-a9jBBRygX1Bh5lt8GZjXDzyOB+bWve9EiO7tROUtj/E="
        crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN"
        crossorigin="anonymous"></script>
</body>
</html>
