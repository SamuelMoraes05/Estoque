<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="wid_Usuarioth=device-wid_Usuarioth, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php

    if (!isset($_SESSION)) {
        session_start();
    }

    if (!isset($_SESSION['id_Usuario'])) {
        die('Parece que ainda não foi realizado o seu processo de autenticação.<br> Solicitamos que efetue o login para 
        prosseguir com as suas atividades.<p><a href="index.php">Clique Aqui</a> ou na imagem abaixo</p>
    <a href="index.php"><img src="Tiny people standing near stop sign flat vector illustration.jpg" height="500" 
    width="650"></a>;

    ');

    }
    ?>

</body>

</html>