<?php 
require("protected.php");
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Cadastro</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
    <style>
	.quadrado {
		width: auto;
		height: auto;
		background-color: rgba(192, 192, 192, 0.5); /* Fundo transparente com cor #c0c0c0 */
		border: 1px solid #000000;
		margin: 20px auto;
		text-align: center;
		padding: 20px;
		font-size: 20px;
		color: #000000;
        
	}
</style>

</head>
<body>
	<div class="limiter">
		<div class="container-login100" style="background-image: url('https://mapa-da-obra-producao.s3.amazonaws.com/wp-content/uploads/2022/09/iStock-1138429558-scaled.jpg');">
			<div class="">
				<div class="container-login100-form-btn">
					<a href="paginaPrincipal.php" class="login100-form-btn">voltar</a>		
				</div>
				<br>
	
			</div>
			<div class="quadrado">
                <br>
                <div style="display: flex;">
                    <a href="chave1.php" style="margin-right: 250px;">
                        <img src="chave-inteligente.png" alt="" height="60" width="60">
                        <h3>Chave 1</h3>
                    </a>
                    <a href="chave2.php" style="margin-right: 5px;">
                        <img src="chave-inteligente.png" alt="" height="60" width="60">
                        <h3>Chave 2</h3>
                    </a>
                </div>
                <br><br>
                <div style="display: flex;">
                    <a href="chave3.php" style="margin-right: 250px;">
                        <img src="chave-inteligente.png" alt="" height="60" width="60">
                        <h3>Chave 3</h3>
                    </a>
                    <a href="chave4.php" style="margin-right: 5px;">
                        <img src="chave-inteligente.png" alt="" height="60" width="60">
                        <h3>Chave 4</h3>
                    </a>
                </div>
                <br><br>
                <div style="display: flex;">
                    <a href="chave5.php" style="margin-right: 250px;">
                        <img src="chave-inteligente.png" alt="" height="60" width="60">
                        <h3>Chave 5</h3>
                    </a>
                    <a href="chave6.php" style="margin-right: 5px;">
                        <img src="chave-inteligente.png" alt="" height="60" width="60">
                        <h3>Chave 6</h3>
                    </a>
                </div>
                <br><br>
                <div style="display: flex;">
                    <a href="chave7.php" style="margin-right: 250px;">
                        <img src="chave-inteligente.png" alt="" height="60" width="60">
                        <h3>Chave 7</h3>
                    </a>
                    <a href="chave8.php" style="margin-right: 5px;">
                        <img src="chave-inteligente.png" alt="" height="60" width="60">
                        <h3>Chave 8</h3>
                    </a>
                </div>

                    
                
                
            </div>

		</div>
	</div>
</body>
</html>
